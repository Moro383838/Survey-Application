const app = require("./app");
const { connectToDB } = require("./Config/DB");
const port = process.env.PORT || 5000;
const CornJob = require("./Controllers/CornJob");

connectToDB();

CornJob();
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
