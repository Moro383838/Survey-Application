const express = require("express");
const router = express.Router();
const {
    getSurveySummary,
    getSurveyTracking,
    getSurveyAnalysis
} = require("../Controllers/AnalyticsController");
const { verifyTokenAndAdmin } = require("../middleware/verifyToken");

//get summary of survey
router.get(
    "/survey/:id/summary",
    verifyTokenAndAdmin,
    getSurveySummary
);

//get tracking of survey
router.get(
    "/survey/:id/tracking",
    verifyTokenAndAdmin,
    getSurveyTracking
);

//get analysis of survey
router.get(
    "/survey/:id/analysis",
    verifyTokenAndAdmin,
    getSurveyAnalysis
);

module.exports = router;
