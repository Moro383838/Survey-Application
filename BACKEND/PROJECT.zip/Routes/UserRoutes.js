const router = require("express").Router();
const {
  verifyToken,
  verifyTokenAndAdmin,
} = require("../middleware/verifyToken");
const {
  UserStatsCtrl,
  createUser,
  updateUserCtrl,
  getUserDetails,
  deleteUserCtrl,
  getAllUsersCtrl,
  getUserByIdCtrl,
  getUserStatsCtrl,

} = require("../Controllers/UserController");
//create user only admin
router
  .route("/")
  .post(verifyTokenAndAdmin, createUser)
  .get(verifyTokenAndAdmin, getAllUsersCtrl);
//get user details only authorized
router.get("/analytics/stats", verifyTokenAndAdmin, getUserStatsCtrl);
router.get("/profile", verifyToken, getUserDetails);
//update user only admin
router
  .route("/:id")
  .put(verifyTokenAndAdmin, updateUserCtrl)
  .delete(verifyTokenAndAdmin, deleteUserCtrl)
  .get(verifyTokenAndAdmin, getUserByIdCtrl);
//get user stats only admin
module.exports = router;
