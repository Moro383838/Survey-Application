const express = require("express");
const router = express.Router();
const {
  getAvailableSurveysCtrl,
  submitResponseCtrl,
  getSurveyProfileCtrl,
} = require("../Controllers/ResponseController");
const { verifyToken } = require("../middleware/verifyToken");
//get available survies for school/s
router.get("/available", verifyToken, getAvailableSurveysCtrl);
router.get("/profile/:surveyId", verifyToken, getSurveyProfileCtrl);
//submit response
router.post("/submit/:surveyId", verifyToken, submitResponseCtrl);

module.exports = router;
