const { sequelize } = require("../Config/DB");
const { QueryTypes } = require("sequelize");
const cron = require('node-cron');

const CornJob = () => {
    console.log("⏰ Cron Jobs Service Started...");

    cron.schedule('0 0 * * *', async () => {
        console.log("🔄 Checking for periodic surveys...");
        try {
            const result = await sequelize.query(
                `SELECT fn_process_periodic_surveys() as count`,
                { type: QueryTypes.SELECT }
            );

            const count = result[0].count;
            if (count > 0) {
                console.log(`Generated ${count} new periodic surveys.`);
            } else {
                console.log(` No periodic surveys needed today.`);
            }
        } catch (err) {
            console.error("Periodic Job Error:", err);
        }
    });

    cron.schedule('*/10 * * * *', async () => {
        console.log("Checking survey start/end dates...");
    });
    cron.schedule('*/10 * * * *', async () => {
        console.log("Checking survey start/end dates...");

        try {
            // 1. النشر التلقائي
            const activationResult = await sequelize.query(
                `SELECT fn_activate_scheduled_surveys() as count`,
                { type: QueryTypes.SELECT }
            );
            const activatedCount = activationResult[0].count;

            if (activatedCount > 0) {
                console.log(` Automatically activated ${activatedCount} surveys.`);
            }

            // 2. الإغلاق التلقائي
            const closingResult = await sequelize.query(
                `SELECT fn_close_expired_surveys() as count`,
                { type: QueryTypes.SELECT }
            );
            const closedCount = closingResult[0].count;

            if (closedCount > 0) {
                console.log(`🛑 Automatically closed ${closedCount} surveys.`);
            }

        } catch (err) {
            console.error(" Status Job Error:", err.message);
        }
    });
};

module.exports = CornJob;