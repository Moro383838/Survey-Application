<template>
  <button class="back-button" @click="goBack" :title="title">
    <span class="back-icon">{{ icon }}</span>
    <span class="back-text">{{ text }}</span>
  </button>
</template>

<script setup>
import { useRouter } from 'vue-router'

const props = defineProps({
  text: {
    type: String,
    default: 'رجوع'
  },
  icon: {
    type: String,
    default: '←'
  },
  title: {
    type: String,
    default: 'العودة للصفحة السابقة'
  }
})

const router = useRouter()

const goBack = () => {
  router.back()
}
</script>

<style scoped>
.back-button {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  background: linear-gradient(135deg, #002623, #001a18);
  color: #b9a779;
  border: 1px solid #b9a779;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.back-button:hover {
  background: linear-gradient(135deg, #003d38, #002623);
  color: white;
  border-color: #b9a779;
  box-shadow: 0 4px 12px rgba(0, 38, 35, 0.2);
  transform: translateX(4px);
}

.back-button:active {
  transform: translateX(2px);
  box-shadow: 0 2px 6px rgba(0, 38, 35, 0.15);
}

.back-icon {
  font-size: 16px;
  font-weight: 700;
  transition: transform 0.3s ease;
}

.back-button:hover .back-icon {
  transform: translateX(4px);
}

.back-text {
  white-space: nowrap;
}

/* Responsive */
@media (max-width: 480px) {
  .back-button {
    padding: 8px 16px;
    font-size: 13px;
  }
  
  .back-icon {
    font-size: 14px;
  }
}
</style>
